package perspective.better_camera_perspective.client.clips;

import java.util.Collections;
import java.util.List;
import mchorse.bbs_mod.camera.clips.CameraClipContext;
import mchorse.bbs_mod.camera.clips.misc.TrackerFrame;
import mchorse.bbs_mod.camera.clips.overwrite.KeyframeClip;
import mchorse.bbs_mod.camera.data.Angle;
import mchorse.bbs_mod.camera.data.Point;
import mchorse.bbs_mod.camera.data.Position;
import mchorse.bbs_mod.camera.values.ValuePoint;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.utils.Anchor;
import mchorse.bbs_mod.settings.values.core.ValueString;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.settings.values.numeric.ValueInt;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.clips.Clip;
import mchorse.bbs_mod.utils.clips.ClipContext;
import mchorse.bbs_mod.utils.joml.Matrices;
import mchorse.bbs_mod.utils.keyframes.Keyframe;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.factories.KeyframeFactories;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.joml.Vector3d;
import org.joml.Vector3f;
import perspective.better_camera_perspective.data.XyzFrameData;
import perspective.better_camera_perspective.data.XyzFrameDataKeyframeFactory;
import perspective.better_camera_perspective.data.PhaseFrameData;
import perspective.better_camera_perspective.data.PhaseFrameDataKeyframeFactory;

/**
 * 多样追踪（MultiTracker）——客户端剪辑类。
 *
 * 继承 {@link KeyframeClip}（拥有 8 个关键帧通道 + additive），
 * 并复制了 {@code TrackerClientClip} 的骨骼追踪求值逻辑（位移位 0-2、角度位 3-5）。
 *
 * 播放求值顺序：
 *   1. 追踪求值（若设置了追踪目标，按 active 位掩码用目标骨骼矩阵覆盖对应的位置/角度轴）；
 *   2. 关键帧插值（X/Y/Z/yaw/pitch/roll/fov/distance 由曲线驱动，等效「关键帧」剪辑）——关键帧优先。
 *
 * 默认 active = 63（六位全开）时行为接近原版「追踪器」；关掉某一位后，
 * 该轴改由关键帧曲线驱动——这就是「多样追踪」的核心玩法。
 */
@Environment(EnvType.CLIENT)
public class MultiTrackerClientClip extends KeyframeClip {
    /** 追踪目标演员的 replay 稳定 ID。 */
    public final ValueString selector = new ValueString("selector", "");
    /** 相对追踪目标的偏移。 */
    public final ValuePoint offset = new ValuePoint("offset", new Point(0.0, 0.0, 0.0));
    /** 追踪视角角度。 */
    public final ValuePoint angle = new ValuePoint("angle", new Point(0.0, 0.0, 0.0));
    /** 追踪的骨骼/附件路径。 */
    public final ValueString group = new ValueString("group", "");
    /** 看向目标。 */
    public final ValueBoolean lookAt = new ValueBoolean("look_at", false);
    /** 相对模式。 */
    public final ValueBoolean relative = new ValueBoolean("relative");
    /** 位掩码（0-2 位移，3-5 角度；默认 63 全开）。 */
    public final ValueInt active = new ValueInt("active", 63, 0, 63);
    /**
     * anchor 追踪轴（v0.3）：追踪目标（演员+部位）的时间轴覆盖通道，原理同模型数据的 anchor 轴。
     * 无关键帧 / 空值 → 回退剪辑属性 selector/group；有关键帧非空 → 以 anchor 轴为准；
     * 相邻关键帧目标不同时按 previous/x 过渡插值，跨演员平滑切换。
     */
    public final KeyframeChannel<Anchor> anchor = new KeyframeChannel<>("anchor", KeyframeFactories.ANCHOR);

    /**
     * 帧级小类存储通道（V1.5.4-Alpha 十版重构）：
     * 每个 XYZ 关键帧独立携带「游动值 / 追踪相对 / 追踪绝对 / 帧级游动模式 / 帧级追踪模式」，
     * 游动与追踪各存各的、模式每帧独立，不再共用 double 池或剪辑级共享模式，
     * 杜绝「游动段 ⇄ 追踪段」相互污染导致的坐标偏差。
     */
    public final KeyframeChannel<XyzFrameData> xd = new KeyframeChannel<>("xd", XyzFrameDataKeyframeFactory.INSTANCE);
    public final KeyframeChannel<XyzFrameData> yd = new KeyframeChannel<>("yd", XyzFrameDataKeyframeFactory.INSTANCE);
    public final KeyframeChannel<XyzFrameData> zd = new KeyframeChannel<>("zd", XyzFrameDataKeyframeFactory.INSTANCE);

    /**
     * 相位追踪轴（V1.6.1-Alpha）：每帧独立开关（默认关）+ 朝向跟随强度。
     *
     * 开启时读取关键帧驱动的最终相机位置与被追踪演员位置，把相机朝向平滑转向演员
     * （位置不被修改，非完全锁定式跟踪）。值类型 {@link PhaseFrameData}
     * （单独类属性，不污染 xd/yd/zd 四值存储）。
     */
    public final KeyframeChannel<PhaseFrameData> phase = new KeyframeChannel<>("phase", PhaseFrameDataKeyframeFactory.INSTANCE);

    /** 相对模式所需的进入本剪辑前的相机位置（等效 EntityClip.position）。 */
    public Position position = new Position(0.0F, 0.0F, 0.0F, 0.0F, 0.0F);

    /**
     * 单次 applyClip 内的追踪求值缓存（V1.7.19-Alpha）：
     * 同一 tick 上「目标 + 参考点」相同的 track() 结果直接复用，
     * 避免 主目标 / 过渡端 / 相位追踪 对同一目标重复求解并重复走 applyUnderneath。
     */
    private final java.util.Map<String, Position> trackCache = new java.util.HashMap<>();

    public MultiTrackerClientClip() {
        this.add(this.selector);
        this.add(this.offset);
        this.add(this.angle);
        this.add(this.group);
        this.add(this.lookAt);
        this.add(this.relative);
        this.add(this.active);
        this.add(this.anchor);
        this.add(this.xd);
        this.add(this.yd);
        this.add(this.zd);
        this.add(this.phase);
    }

    @Override
    public void applyClip(ClipContext context, Position position) {
        // 每帧清空追踪求值缓存（同帧内同目标 + 同参考点可直接复用）
        this.trackCache.clear();
        boolean additive = this.additive.get();
        boolean lookAt = this.lookAt.get();
        // v1.0：XYZ 关键帧固定为「相对值」语义（锚点 + 关键帧偏移合成；lookAt / 叠加除外）
        boolean relativeMode = !additive && !lookAt;
        // v1.5.4-Alpha 二版：进入本剪辑前的相机位置快照，供无锚点空通道回退（不飞回 0 0 0）
        Position basePosition = position.copy();

        // —— 1) 追踪目标解析（统一采样器，V1.7.19-Alpha）——
        // 口径一律以「本帧有效 anchor 关键帧」为准（last ≤ tick），不再用 interpolate()：
        // BBS 的整数刻段前移 + Anchor 工厂离散硬切换会让 interpolate 在关键帧刻读到下一帧状态，
        // 这正是「每到一个关键帧就回跳一次」的结构性根因。
        AnchorSampler sample = AnchorSampler.sample(this.anchor, (float) context.relativeTick + context.transition);

        String sel = this.selector.get();
        String grp = this.group.get();
        String fromSel = null;
        String fromGrp = null;
        float blend = 1.0F;
        boolean blendSource = false;

        if (sample.cur != null && sample.cur.hasTarget()) {
            sel = sample.cur.replay;
            grp = sample.cur.attachment;
        }

        // 追踪 → 追踪（不同目标）：段内从 cur 目标过渡到 next 目标（进度 = sample.t）
        if (sample.isCrossTarget()) {
            sel = sample.next.replay;
            grp = sample.next.attachment;
            fromSel = sample.cur.replay;
            fromGrp = sample.cur.attachment;
            blend = sample.t;
            blendSource = true;
        }

        // —— 2) 追踪求值（含过渡混合）——
        // 路线由「本帧 anchor 关键帧值」判定（<无> = 游动；绑定模型 / 伪装 = 追踪）；
        // anchor 通道完全无关键帧时回落剪辑属性绑定。
        float tick = (float) context.relativeTick + context.transition;
        boolean trackRoute = sample.cur == null ? !this.selector.get().isEmpty() : sample.routeIsTrack();
        boolean tracked = false;
        boolean trackResolved = false;
        double anchorX = 0.0D, anchorY = 0.0D, anchorZ = 0.0D;
        // v1.5.4-Alpha 四版：记录追踪角度，供「关键帧空 / 无帧段」时回退（不把角度读成 0）
        float trackYaw = 0.0F, trackPitch = 0.0F, trackRoll = 0.0F;

        if (trackRoute && !sel.isEmpty()) {
            Position current = this.track(context, position, sel, grp, lookAt);
            tracked = true;
            if (current != null) {
                trackResolved = true;
                if (blendSource && blend < 1.0F) {
                    Position from = fromSel == null || fromSel.isEmpty() ? null : this.track(context, position, fromSel, fromGrp, lookAt);
                    Position base = from != null ? from : position.copy();
                    current = lerp(base, current, blend);
                }

                if (relativeMode) {
                    // 相对值语义（默认）：存追踪锚点，角度照常覆盖；XYZ 在关键帧插值后合成
                    anchorX = current.point.x;
                    anchorY = current.point.y;
                    anchorZ = current.point.z;
                    trackYaw = current.angle.yaw;
                    trackPitch = current.angle.pitch;
                    trackRoll = current.angle.roll;
                    position.angle.yaw = this.isActive(3) ? current.angle.yaw : position.angle.yaw;
                    position.angle.pitch = this.isActive(4) ? current.angle.pitch : position.angle.pitch;
                    position.angle.roll = this.isActive(5) ? current.angle.roll : position.angle.roll;
                } else {
                    // lookAt / 叠加：追踪直接覆盖对应轴（lookAt 时 XYZ 未被覆盖，保持关键帧绝对值）
                    position.point.x = this.isActive(0) ? current.point.x : position.point.x;
                    position.point.y = this.isActive(1) ? current.point.y : position.point.y;
                    position.point.z = this.isActive(2) ? current.point.z : position.point.z;
                    position.angle.yaw = this.isActive(3) ? current.angle.yaw : position.angle.yaw;
                    position.angle.pitch = this.isActive(4) ? current.angle.pitch : position.angle.pitch;
                    position.angle.roll = this.isActive(5) ? current.angle.roll : position.angle.roll;
                }
            } else {
                // 追踪目标解析失败（如绑定的伪装未实例化进影片）：锚点视为 0（关键帧值即绝对坐标），
                // 角度回退进入前值 —— 不把角度读成 0 / 平视跳变。
                trackYaw = basePosition.angle.yaw;
                trackPitch = basePosition.angle.pitch;
                trackRoll = basePosition.angle.roll;
            }
        }

        // —— 3) 关键帧插值（KeyframeClip 的全部逻辑）—— 关键帧优先。
        super.applyClip(context, position);

        // —— 3.5) XYZ 帧级小类存储求值 + 游动⇄追踪过渡（V1.5.4-Alpha 十版）——
        // 每帧独立的「游动值 / 追踪相对 / 追踪绝对 + 帧级模式」，三轴分别求最终世界坐标；
        // 游动 ⇄ 追踪段（anchor 相邻帧状态不同）两端按段内进度 lerp，
        // 不再瞬间跳转，也不再共用池子相互污染。仅在相对模式（非 lookAt / 非叠加）生效。
        if (relativeMode) {
            RouteBlend rb = this.routeBlend(context, tick, lookAt);
            Point debug = this.offset.get();

            if (this.isActive(0)) {
                position.point.x = this.resolvePointAxis(0, tick, tracked, trackResolved, anchorX, basePosition.point.x, debug.x, rb);
            }
            if (this.isActive(1)) {
                position.point.y = this.resolvePointAxis(1, tick, tracked, trackResolved, anchorY, basePosition.point.y, debug.y, rb);
            }
            if (this.isActive(2)) {
                position.point.z = this.resolvePointAxis(2, tick, tracked, trackResolved, anchorZ, basePosition.point.z, debug.z, rb);
            }
            if (this.isActive(3)) {
                position.angle.yaw = this.resolveAngleAxis(0, tick, tracked, trackYaw, basePosition.angle.yaw, rb);
            }
            if (this.isActive(4)) {
                position.angle.pitch = this.resolveAngleAxis(1, tick, tracked, trackPitch, basePosition.angle.pitch, rb);
            }
            if (this.isActive(5)) {
                position.angle.roll = this.resolveAngleAxis(2, tick, tracked, trackRoll, basePosition.angle.roll, rb);
            }
        }

        // —— 3.6) 相位追踪（V1.6.1-Alpha）——
        // 帧级开关轴：开启时读取关键帧驱动的最终相机位置与被追踪演员位置，
        // 把相机朝向平滑转向演员（位置不被修改，非完全锁定式跟踪）。
        // 目标演员 = 步骤 1 解析后的 sel / grp（anchor 轴当前 tick 优先，回退剪辑属性）。
        this.applyPhaseTracking(context, tick, sel, grp, position);

        // —— 6) 视野：空 / 播放头无帧段回退进入前值（两条路线一致，不再被读成 0）——
        if (this.isActive(6)) {
            position.angle.fov = (float) safeValue(this.fov, tick, (double) basePosition.angle.fov);
        }
    }

    /**
     * v1.5.4-Alpha 四版：安全读取关键帧通道在当前 tick 的值。
     * 通道为空、或播放头不在任何关键帧段（此时 interpolate 会返回 0）时返回 fallback，
     * 否则返回插值——杜绝「空通道 / 无帧段被读成 0，相机与角度飞回原点」的跳变。
     */
    private static double safeValue(KeyframeChannel<Double> channel, float tick, double fallback) {
        return channel.isEmpty() || channel.findSegment(tick) == null ? fallback : channel.interpolate(tick);
    }

    /**
     * 相位追踪轴离散读取（V1.6.1-Alpha）：返回该 tick 处或之前最近的相位关键帧值。
     * 相位追踪开关是事件性的（某帧开 → 之后一直生效，直到某帧关），不做连续插值；
     * 播放头早于首帧时回落首帧；通道无任何关键帧返回 null（默认关，功能不干预画面）。
     */
    private PhaseFrameData phaseValueAt(float tick) {
        if (this.phase.isEmpty()) {
            return null;
        }
        PhaseFrameData best = null;
        PhaseFrameData first = null;
        float bestTick = -Float.MAX_VALUE;
        for (Keyframe keyframe : this.phase.getKeyframes()) {
            PhaseFrameData value = (PhaseFrameData) keyframe.getValue();
            if (first == null) {
                first = value;
            }
            if (keyframe.getTick() <= tick && keyframe.getTick() >= bestTick) {
                best = value;
                bestTick = keyframe.getTick();
            }
        }
        return best != null ? best : first;
    }

    /**
     * 相位追踪播放求值（V1.6.1-Alpha）。
     *
     * 相位追踪 = 「自动 lookAt」：开启时用关键帧驱动的最终相机位置（游动 / 追踪世界坐标）
     * 解析被追踪演员（伪装）相对相机的方向，把相机 yaw / pitch 平滑转向演员——
     * 位置不被修改（非完全锁定式跟踪），因此：
     *   - 演员移动而相机不动（相机关键帧保持）：相机转头盯住演员，完成跟踪录制；
     *   - 演员与相机同时移动（相机关键帧照常驱动）：相机在移动中时刻追踪演员，丝滑录制。
     *
     * smooth（0~1）控制跟随强度：1 完全盯住演员；0 保持关键帧朝向（等同关闭）；
     * roll 不参与相位追踪；目标解析失败 / 未开启时完全不干预画面。
     */
    private void applyPhaseTracking(ClipContext context, float tick, String sel, String grp, Position position) {
        PhaseFrameData data = this.phaseValueAt(tick);
        if (data == null || !data.enabled || sel == null || sel.isEmpty()) {
            return;
        }
        if (!(context instanceof CameraClipContext camera)) {
            return;
        }
        IEntity entity = camera.entities.get(sel);
        if (entity == null) {
            return;
        }
        TrackerFrame frame = TrackerFrame.resolve(
            camera.entities, entity, grp, position.point.x, position.point.y, position.point.z, context.transition
        );
        if (frame == null) {
            return;
        }
        if (this.relative.get()) {
            frame.relative(position, this.position);
        }
        Angle look = frame.lookAtAngles(this.offset.get(), this.angle.get());
        float smooth = (float) Math.max(0.0D, Math.min(1.0D, data.smooth));
        position.angle.yaw = lerpAngle(position.angle.yaw, look.yaw, smooth);
        position.angle.pitch = lerpAngle(position.angle.pitch, look.pitch, smooth);
    }

    /**
     * V1.7.19-Alpha：检测 anchor 关键帧的「游动 ⇄ 追踪」过渡段。
     * 与 {@link AnchorSampler} 同源：cur = 本帧关键帧、next = 下一关键帧、t = 段内进度。
     * 两端路线不同（一空一绑）时返回混合信息，并解析「绑定端」在当前 tick 的锚点 Position；
     * 两端路线相同返回 null（无过渡，走对应路线）。
     */
    private RouteBlend routeBlend(ClipContext context, float tick, boolean lookAt) {
        AnchorSampler sample = AnchorSampler.sample(this.anchor, tick);

        if (!sample.isCrossRoute()) {
            return null;
        }
        if (sample.t <= 0.0F || sample.t >= 1.0F) {
            // 端点交给各自的纯路线分支处理，避免两端重复混合
            return null;
        }

        boolean fromIsTrack = AnchorSampler.hasTarget(sample.cur);
        RouteBlend rb = new RouteBlend(sample.t, fromIsTrack);
        Anchor trackEnd = fromIsTrack ? sample.cur : sample.next;

        Position cur = this.track(context, this.position, trackEnd.replay, trackEnd.attachment, lookAt);
        if (cur != null) {
            rb.trackPoint[0] = (float) cur.point.x;
            rb.trackPoint[1] = (float) cur.point.y;
            rb.trackPoint[2] = (float) cur.point.z;
            rb.trackAngle[0] = cur.angle.yaw;
            rb.trackAngle[1] = cur.angle.pitch;
            rb.trackAngle[2] = cur.angle.roll;
            rb.trackResolved = true;
        }
        return rb;
    }

    /** 路线过渡信息：段内进度 t + 过渡起点是否为追踪端 + 追踪端锚点在当前 tick 的位置 / 角度。 */
    private static final class RouteBlend {
        final float t;
        /** true = 起点是追踪端（追踪 → 游动）；false = 起点是游动端（游动 → 追踪）。 */
        final boolean fromIsTrack;
        final float[] trackPoint = new float[3];
        final float[] trackAngle = new float[3];
        boolean trackResolved;

        RouteBlend(float t, boolean fromIsTrack) {
            this.t = t;
            this.fromIsTrack = fromIsTrack;
        }
    }

    /**
     * 过渡段专用的「纯线性」帧值（V1.7.21-Alpha）。
     *
     * BBS 的关键帧带「前 / 后」手柄（duration / motionShift），{@code channel.interpolate()} 会在每个
     * 关键帧附近做缓动；混进「游动 ⇄ 追踪」过渡后，两端各自缓动再线性混合，观感就是淡入淡出。
     * 过渡段一律按相邻两帧的**原始值线性插值**，不吃任何缓动，保证衔接是匀速直线。
     */
    private static XyzFrameData linearFdAt(KeyframeChannel<XyzFrameData> data, float tick) {
        if (data == null || data.isEmpty()) {
            return null;
        }
        Keyframe prev = null;
        Keyframe next = null;
        for (Keyframe keyframe : data.getKeyframes()) {
            float kt = keyframe.getTick();
            if (kt <= tick) {
                if (prev == null || kt >= prev.getTick()) {
                    prev = keyframe;
                }
            } else if (next == null || kt < next.getTick()) {
                next = keyframe;
            }
        }
        if (prev == null && next == null) {
            return null;
        }
        if (prev == null) {
            return ((XyzFrameData) next.getValue()).copy();
        }
        XyzFrameData a = (XyzFrameData) prev.getValue();
        if (a == null) {
            return null;
        }
        if (next == null) {
            return a.copy();
        }
        XyzFrameData b = (XyzFrameData) next.getValue();
        if (b == null) {
            return a.copy();
        }
        float span = next.getTick() - prev.getTick();
        float t = span <= 0.0F ? 0.0F : (tick - prev.getTick()) / span;
        if (t < 0.0F) {
            t = 0.0F;
        } else if (t > 1.0F) {
            t = 1.0F;
        }
        XyzFrameData out = a.copy();
        out.roamValue = a.roamValue + (b.roamValue - a.roamValue) * (double) t;
        out.trackRelative = a.trackRelative + (b.trackRelative - a.trackRelative) * (double) t;
        out.trackAbsolute = a.trackAbsolute + (b.trackAbsolute - a.trackAbsolute) * (double) t;
        // 模式位取左侧帧（与「本帧状态」口径一致），不做插值
        return out;
    }

    /** 过渡段专用的「纯线性」角度值：相邻两帧原始值线性插值，不吃缓动。 */
    private static double linearValueAt(KeyframeChannel<Double> channel, float tick, double fallback) {
        if (channel == null || channel.isEmpty()) {
            return fallback;
        }
        Keyframe prev = null;
        Keyframe next = null;
        for (Keyframe keyframe : channel.getKeyframes()) {
            float kt = keyframe.getTick();
            if (kt <= tick) {
                if (prev == null || kt >= prev.getTick()) {
                    prev = keyframe;
                }
            } else if (next == null || kt < next.getTick()) {
                next = keyframe;
            }
        }
        if (prev == null && next == null) {
            return fallback;
        }
        if (prev == null) {
            return (Double) next.getValue();
        }
        double a = (Double) prev.getValue();
        if (next == null) {
            return a;
        }
        double b = (Double) next.getValue();
        float span = next.getTick() - prev.getTick();
        float t = span <= 0.0F ? 0.0F : (tick - prev.getTick()) / span;
        if (t < 0.0F) {
            t = 0.0F;
        } else if (t > 1.0F) {
            t = 1.0F;
        }
        return a + (b - a) * (double) t;
    }

    /** 取某轴当前 tick 的帧级数据（新通道优先；新通道为空时才回退父类老 Double 通道，兼容老存档）。 */
    private static XyzFrameData fdAt(KeyframeChannel<XyzFrameData> data, KeyframeChannel<Double> old, float tick) {
        if (data != null && !data.isEmpty()) {
            // V1.7.19-Alpha：新通道只要有帧就一律以它为准——即便当前 tick 落在无段区间（首帧之前），
            // 也不再回退旧通道，避免父类 x/y/z 残留的 tick 0 默认帧把画面钉成常数。
            if (data.findSegment(tick) != null) {
                return data.interpolate(tick);
            }
            return null;
        }
        if (old != null && !old.isEmpty() && old.findSegment(tick) != null) {
            double v = old.interpolate(tick);
            return new XyzFrameData(v, v, v, 1, 0);
        }
        return null;
    }

    /**
     * 游动端世界坐标：roamValue 即相机世界绝对坐标。
     * V1.8.0-Alpha 起游动恒定绝对语义（UI 已移除「相对」子模式）；
     * 此处保留 roamMode == 0 分支仅为旧存档兼容——历史相对态帧的世界坐标 = roamValue + 剪辑「偏移」，
     * 保证升级前后画面零偏移。新写入帧一律 roamMode == 1，直接取 roamValue。
     */
    private double roamWorld(KeyframeChannel<XyzFrameData> data, KeyframeChannel<Double> old, float tick,
                             double baseAxis, double debugAxis) {
        XyzFrameData fd = fdAt(data, old, tick);
        if (fd == null) {
            return baseAxis;
        }
        return roamWorld(fd, baseAxis, debugAxis);
    }

    /** 游动端世界坐标（已拿到帧值时的重载，供过渡段线性求值复用）。 */
    private double roamWorld(XyzFrameData fd, double baseAxis, double debugAxis) {
        return fd.roamMode == 1 ? fd.roamValue : fd.roamValue + debugAxis;
    }

    /** 追踪端世界坐标：绝对模式用帧 trackAbsolute；相对模式用「锚点 + trackRelative」。无数据回退锚点 / baseAxis。 */
    private double trackWorld(KeyframeChannel<XyzFrameData> data, KeyframeChannel<Double> old, float tick,
                              double anchorAxis, boolean anchorResolved, double baseAxis) {
        XyzFrameData fd = fdAt(data, old, tick);
        if (fd == null) {
            return anchorResolved ? anchorAxis : baseAxis;
        }
        return trackWorld(fd, anchorAxis, anchorResolved, baseAxis);
    }

    /** 追踪端世界坐标（已拿到帧值时的重载）。 */
    private double trackWorld(XyzFrameData fd, double anchorAxis, boolean anchorResolved, double baseAxis) {
        if (fd.trackMode == 1) {
            return fd.trackAbsolute;
        }
        return anchorResolved ? anchorAxis + fd.trackRelative : baseAxis;
    }

    /** 求一个位置轴的最终世界坐标（含「起点路线 → 终点路线」定向过渡）。 */
    private double resolvePointAxis(int axis, float tick, boolean tracked, boolean trackResolved,
                                    double anchorAxis, double baseAxis, double debugAxis, RouteBlend rb) {
        KeyframeChannel<XyzFrameData> data = axis == 0 ? this.xd : axis == 1 ? this.yd : this.zd;
        KeyframeChannel<Double> old = axis == 0 ? this.x : axis == 1 ? this.y : this.z;
        boolean inBlend = rb != null && rb.t > 0.0F && rb.t < 1.0F;
        if (inBlend) {
            // V1.7.21-Alpha：过渡段两端都按「原始值线性插值」求，避免两侧各自缓动叠成淡入淡出
            XyzFrameData fd = linearFdAt(data, tick);
            if (fd == null) {
                fd = fdAt(data, old, tick);
            }
            double roam = fd == null ? baseAxis : this.roamWorld(fd, baseAxis, debugAxis);
            double track = fd == null
                ? (rb.trackResolved ? rb.trackPoint[axis] : baseAxis)
                : this.trackWorld(fd, rb.trackPoint[axis], rb.trackResolved, baseAxis);
            // 过渡方向由起点路线决定：追踪 → 游动 时 from = 追踪端，反之 from = 游动端
            double from = rb.fromIsTrack ? track : roam;
            double to = rb.fromIsTrack ? roam : track;
            return from + (to - from) * (double) rb.t;
        }
        if (tracked) {
            return this.trackWorld(data, old, tick, anchorAxis, trackResolved, baseAxis);
        }
        return this.roamWorld(data, old, tick, baseAxis, debugAxis);
    }

    /** 求一个角度轴的最终角度（过渡段按起点路线定向走最短弧；否则关键帧插值，回退对应路线角度）。 */
    private float resolveAngleAxis(int axis, float tick, boolean tracked, float trackFallback,
                                   float baseFallback, RouteBlend rb) {
        KeyframeChannel<Double> ch = axis == 0 ? this.yaw : axis == 1 ? this.pitch : this.roll;
        boolean inBlend = rb != null && rb.t > 0.0F && rb.t < 1.0F;
        if (inBlend) {
            // V1.7.21-Alpha：过渡段角度同样按原始值线性插值
            float roam = (float) linearValueAt(ch, tick, (double) baseFallback);
            float track = (float) linearValueAt(ch, tick, (double) rb.trackAngle[axis]);
            float from = rb.fromIsTrack ? track : roam;
            float to = rb.fromIsTrack ? roam : track;
            return lerpAngle(from, to, rb.t);
        }
        return (float) safeValue(ch, tick, tracked ? (double) trackFallback : (double) baseFallback);
    }

    /** 追踪求值：返回按 active 位过滤后的 Position 副本；目标实体或帧无效时返回 null。 */
    private Position track(ClipContext context, Position position, String sel, String grp, boolean lookAt) {
        if (!(context instanceof CameraClipContext camera)) {
            return null;
        }

        IEntity entity = camera.entities.get(sel);
        if (entity == null) {
            return null;
        }

        // 同帧缓存：目标 + 朝向模式 + 参考点三者一致时直接复用（省一次 applyUnderneath 与骨骼求解）
        String cacheKey = sel + "|" + grp + "|" + lookAt
            + "|" + Math.round(position.point.x * 8.0D)
            + "|" + Math.round(position.point.y * 8.0D)
            + "|" + Math.round(position.point.z * 8.0D);
        Position cached = this.trackCache.get(cacheKey);
        if (cached != null) {
            return cached.copy();
        }

        if (!context.applyUnderneath(this.tick.get(), 0.0F, this.position)) {
            this.position.copy(position);
        }

        TrackerFrame frame = TrackerFrame.resolve(
            camera.entities, entity, grp, position.point.x, position.point.y, position.point.z, context.transition
        );
        if (frame == null) {
            return null;
        }

        if (this.relative.get()) {
            frame.relative(position, this.position);
        }

        Point offset = this.offset.get();
        Point angle = this.angle.get();
        Angle newAngle = lookAt ? frame.lookAtAngles(offset, angle) : frame.angles(angle);
        Position result = position.copy();
        if (lookAt) {
            // lookAt：XYZ 不追踪（由关键帧绝对值驱动），仅角度看向目标
            result.angle.yaw = this.isActive(3) ? newAngle.yaw : result.angle.yaw;
            result.angle.pitch = this.isActive(4) ? newAngle.pitch : result.angle.pitch;
            result.angle.roll = this.isActive(5) ? newAngle.roll : result.angle.roll;
        } else {
            Vector3d newPosition = frame.position(offset);
            result.point.x = this.isActive(0) ? newPosition.x : result.point.x;
            result.point.y = this.isActive(1) ? newPosition.y : result.point.y;
            result.point.z = this.isActive(2) ? newPosition.z : result.point.z;
            result.angle.yaw = this.isActive(3) ? newAngle.yaw : result.angle.yaw;
            result.angle.pitch = this.isActive(4) ? newAngle.pitch : result.angle.pitch;
            result.angle.roll = this.isActive(5) ? newAngle.roll : result.angle.roll;
        }
        this.trackCache.put(cacheKey, result.copy());
        return result;
    }

    /** 两个追踪结果按 t 混合（位置/角度逐分量 lerp，角度按最短弧插值）。 */
    private static Position lerp(Position a, Position b, float t) {
        Position result = new Position();
        result.point.x = a.point.x + (b.point.x - a.point.x) * (double) t;
        result.point.y = a.point.y + (b.point.y - a.point.y) * (double) t;
        result.point.z = a.point.z + (b.point.z - a.point.z) * (double) t;
        result.angle.yaw = lerpAngle(a.angle.yaw, b.angle.yaw, t);
        result.angle.pitch = lerpAngle(a.angle.pitch, b.angle.pitch, t);
        result.angle.roll = lerpAngle(a.angle.roll, b.angle.roll, t);
        return result;
    }

    /**
     * 角度最短弧插值（BBS 角度通道 yaw/pitch/roll 与 {@link Angle#angle} 均为「角度制・度」，
     * 与 {@code TrackerFrame.angles} 内部 {@code Math.toRadians} 的口径一致）。
     *
     * <p>先把差值转弧度再走 atan2(sin, cos) 取 [-180,180] 最短弧，最后转回度。
     * 此前误把度直接传给 sin/cos，导致相位追踪跟随强度 0.9 时每帧仅转约 1~2°
     * （本应转 90%），相机几乎不转向演员、目标始终停在画面边缘——V1.6.1-Alpha 修复。</p>
     */
    private static float lerpAngle(float a, float b, float t) {
        double shortest = Math.atan2(
            Math.sin(Math.toRadians((double) b - (double) a)),
            Math.cos(Math.toRadians((double) b - (double) a))
        );
        return a + (float) Math.toDegrees(shortest) * t;
    }

    public boolean isActive(int bit) {
        return (this.active.get() >> bit & 1) == 1;
    }

    public List<IEntity> getEntities(ClipContext context) {
        String id = this.selector.get();
        if (context instanceof CameraClipContext cameraClipContext && !id.isEmpty()) {
            IEntity entity = cameraClipContext.entities.get(id);
            if (entity != null) {
                return Collections.singletonList(entity);
            }
        }

        return Collections.emptyList();
    }

    @Override
    public Clip create() {
        return new MultiTrackerClientClip();
    }
}
